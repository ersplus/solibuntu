zenity --info --width=500 --height=50 --ok-label="Accepter les licences et continuer" --text="Validation des licences

En choisissant de poursuivre l'installation, vous reconnaissez accepter la licence \
d'utilisation des polices de caractères Microsoft disponible à l'adresse :
http://corefonts.sourceforge.net/eula.htm

L'installation complète de Solibuntu peut être longue du fait du nombre important \
de logiciels à installer. Veuillez ne pas interrompre le processus en cours ..."

zenity --info --width=500 --height=75 --ok-label="Supprimer les données" --text="Attention - Message Important

Si vous poursuivez cette installation, toutes les données de cet ordinateur seront \
supprimées afin de pouvoir installer Solibuntu. \
Si vous désirez annuler cette installation, veuillez éteindre votre ordinateur et \
retirer la clé avant de redémarrer."\


