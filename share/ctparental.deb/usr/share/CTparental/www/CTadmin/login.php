<html>
    <head>
        <title>CTparental DNS filtering</title>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="css/main.css" type="text/css">
        <link rel="stylesheet" href="css/sticky-footer.css" type="text/css">
        <link rel="stylesheet" href="css/dashboard.css" type="text/css">
        
        <script src="js/jquery-1.12.3.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>

    <body>

<?php
include 'locale.php';
$file_passworddiguest="arp1_md5.password";
if (is_file ($file_passworddiguest))
{
    $tab = file($file_passworddiguest);

    if ($tab)
    {
        foreach ($tab as $line)
        {
            $field = explode(":", $line);
            $validUser = trim($field[0]);
            //$realm = trim($field[1]);
            $APR1 = trim($field[1]);
        }
    }
}
else
{
    echo " Error opening the file".$file_passworddiguest;
}
//echo $validUser." ".$APR1;
  $errorMessage = '';
  require("apr1_md5.php");
  // Test de l'envoi du formulaire
  if(!empty($_POST)) 
  {
    // Les identifiants sont transmis ?
    if(!empty($_POST['login']) && !empty($_POST['password'])) 
    {
      // Sont-ils les mêmes que les constantes ?
      if($_POST['login'] !== $validUser ) 
      {
        $errorMessage = gettext('Bad login!');
      }
        elseif( 1 != APR1_MD5::check($_POST['password'], $APR1  )) 
      {  
        $errorMessage = gettext('Bad password!');
      }
        else
      {
        // On ouvre la session
        session_start();
        // On enregistre le login en session
        $_SESSION['login'] = LOGIN;
        // On redirige vers le fichier index.php
        header('Location: index.php');
        exit();
      }
    }
      else
    {
      $errorMessage = gettext('Please enter your login details!');
    }
  }
    echo "<h1 class='page-header'>".gettext('CTparental Administration Interface')."</h1>";
    echo "<div class='col-md-3'>";
    echo "<form action='$_SERVER[PHP_SELF]' method=POST>";
          // Rencontre-t-on une erreur ?
          if(!empty($errorMessage)) 
          {
            echo '<p>', htmlspecialchars($errorMessage) ,'</p>';
          }
    echo "<p>";
    echo "<label for='login'>".gettext('Login')." :</label>";
    echo "</p>";
    echo "<p>";
    echo "<input type='text' name='login' id='login' value='' />";
    echo "</p>";
    echo "<p>";
    echo "<label for='password'>".gettext('Password')." :</label>";
    echo "</p>";
    echo "<p>";
    echo "<input type='password' name='password' id='password' value='' /> ";
    echo "</p>";
    echo "<input type='hidden' name='submit' value='login'>"; 
    echo "<button class='btn btn-primary'>";
echo "<span class='glyphicon glyphicon-download' aria-hidden='true'></span>&nbsp;";
echo gettext('Connection');
echo "</button>";

    echo "</form>";
    echo "<div class='row'>";

?>

    </body>
</html>
