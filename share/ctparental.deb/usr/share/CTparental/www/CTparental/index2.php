<html>
<head>
</head>
<body>
<SCRIPT TYPE="text/javascript">
window.close()
</SCRIPT>
</body>
</html>

